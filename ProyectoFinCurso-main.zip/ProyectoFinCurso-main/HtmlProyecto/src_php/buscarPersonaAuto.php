<?php
include "../src_php/logicaBuscar.php";
$mysqli = new mysqli("localhost","root","","registroalumnos");
session_start();
if($mysqli->connect_error){
    echo" Error al conectar con la base de datos";
}else{
?>
    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../src_css/mostrarRegistro.css">

</head>
<body>
    <div id="container1">
    <table>
    <thead>
    <tr>
        <th>Tipo</th>
        <th colspan='2'>Fecha y Hora</th>
        <th>Motivo</th>
        <th>Persona Autorizada</th>

    </tr>
    </thead>
    <tbody>
    <?php

    $sql =" select * from persautos where alumno = '{$_SESSION['cial']}'";
    $res=$mysqli->query($sql);
     

    while($row= $res->fetch_assoc()){
        echo"
                    <tr>
                        <td>".$row["nombre"]."</td>
                        <td>".$row["apellido1"]."</td>
                        <td>".$row["apellido2"]."</td>
                        <td>".$row["dni"]."</td>
                        <td class='celda'> <a href='../src_php/logicaPersonaAut.php?dni={$row['dni']}' class='buscar'>Seleccionar</a></td>
                    </tr>";
    }




?>
</tbody>
    </table>
        </div>
   
</body>
</html>
<?php
}
?>
