<?php
$mysql = new mysqli("localhost","root","","registroalumnos"); 

if ($mysql->connect_error){
    echo"Error al conectar con la base de datos" . $mysql->connect_error;
}else{
    if(!isset($_POST["id"], $_POST["curso"],$_POST["tutor"],$_POST["turno"])){
                
                echo "Error al recibir los datos"; 
            }else{
                $curso = $_POST["curso"];
                $tutor = strtoupper($_POST["tutor"]);
                $turno = strtoupper($_POST["turno"]);
            

                $sql ="insert into cursos values ('{$id}',
                   '{$curso}','{$tutor}',
                   '{$turno}'
                )";

                $res = $mysql->query($sql);

                if(!$res){
                    echo "Error al insertar los datos en la base de datos" . $mysql->error;
                }else{
                    header("Location:../src_html/opciones.php");
                }
            }
}

$mysql->close();





