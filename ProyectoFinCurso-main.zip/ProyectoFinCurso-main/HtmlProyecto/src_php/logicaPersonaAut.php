<?php

session_start();


if($_GET['dni']){
    $_SESSION["dni"] = $_GET["dni"];
        header("Location:../src_html/directorio.html");
}