<?php
$mysql = new mysqli("localhost","root","","registroalumnos"); 

if ($mysql->connect_error){
    echo"Error al conectar con la base de datos" . $mysql->connect_error;
}else{
    if(!isset($_POST["aula"],$_POST["planta"],$_POST["edificio"])){
                
                echo "Error al recibir los datos"; 
            }else{
                $aula = $_POST["aula"];
                $planta = strtoupper($_POST["planta"]);
                $edificio = strtoupper($_POST["edificio"]);
            

                $sql ="insert into aulas values (
                   '{$aula}','{$planta}',
                   '{$edificio}'
                )";

                $res = $mysql->query($sql);

                if(!$res){
                    echo "Error al insertar los datos en la base de datos" . $mysql->error;
                }else{
                    header("Location:../src_html/opciones.php");
                }
            }
}

$mysql->close();
