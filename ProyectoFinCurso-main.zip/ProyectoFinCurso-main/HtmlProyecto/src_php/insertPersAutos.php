<?php
include 'logicaBase.php';
$mysql = new mysqli("localhost","root","","registroalumnos"); 

if ($mysql->connect_error){
    echo"Error al conectar con la base de datos" . $mysql->connect_error;
}else{
    if(!isset($_POST["dni"], $_POST["nombre"], $_POST["ap1"], $_POST["ap2"], $_POST["parentesco"], $_POST["telefono"], $_POST["email"], $_POST["alumno"])){
                
                echo "Error al recibir los datos"; 
            }else{
                $dni = $_POST["dni"];
                $nombre= strtoupper($_POST["nombre"]);
                $ap1= strtoupper($_POST["ap1"]);
                $ap2= strtoupper($_POST["ap2"]) ;
                $parentesco = $_POST["parentesco"];
                $telefono = $_POST["telefono"];
                $email = $_POST["email"];
                $alumno = $_POST["alumno"];


                $sql ="insert into persautos values (
                   '{$dni}','{$nombre}',
                   '{$ap1}','{$ap2}','{$parentesco}',
                   '{$telefono}','{$email}','{$alumno}'
                )";

                $res = $mysql->query($sql);

                if(!$res){
                    echo "Error al insertar los datos en la base de datos" .$mysql->error;
                }else{
                    header("Location:insertAlumnos.html");
                }
            }

  
}

$mysql->close();
