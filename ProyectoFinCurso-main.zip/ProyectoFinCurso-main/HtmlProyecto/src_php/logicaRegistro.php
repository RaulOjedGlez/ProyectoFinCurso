<?php
include '../src_php/conectar.php';
//conectamos con la base de datos
$mysql = conectar();

session_start();
if(!isset($_SESSION["cial"])){
    if(isset($_GET["cial"])){      
        $_SESSION["cial"] = $_GET["cial"];
        header("Location:buscarPersonaAuto.php");
    }
}else{
    
    if(isset($_GET["tipo"])){
        if($_GET["tipo"] == "entrada"){
            $sql ="insert into ".$_SESSION["cial"]."registro values('Entrada','{$_POST['motivo']}','{$_SESSION['dni']}','{$_POST['fecha']}');";
            $sql2="insert into registro_diario values('Entrada','{$_POST['motivo']}','{$_POST['fecha']}','{$_POST['hora']}','{$_SESSION['cial']}','{$_SESSION['dni']}');";
    
            if(($res = $mysql->query($sql)) && ($res2 = $mysql->query($sql2)) ){
                echo "se ha registrado";
            }else{
                echo $mysql->error;
            }
        }else if($_GET["tipo"] == "salida"){
            $sql3 ="insert into ".$_SESSION["cial"]."registro values('Salida','{$_POST['motivo']}','{$_SESSION['dni']}','{$_POST['fecha']}');";
            $sql4="insert into registro_diario values('Salida','{$_POST['motivo']}','{$_POST['fecha']}','{$_POST['hora']}','{$_SESSION['cial']}','{$_SESSION['dni']}');";
    
            if(($res3 = $mysql->query($sql3)) && ($res4 = $mysql->query($sql4)) ){
                
                    include("../mail_php/sendemail.php");//Mando a llamar la funcion que se encarga de enviar el correo electronico
                    
                    /*Configuracion de variables para enviar el correo*/
                    $mail_username="proyectop66@gmail.com";//Correo electronico saliente ejemplo: tucorreo@gmail.com
                    $mail_userpassword="Hola1234";//Tu contraseña de gmail
                    $mail_addAddress="yurima.cabrera12@gmail.com";//correo electronico que recibira el mensaje
                    $template="../mail_php/email_template.php";//Ruta de la plantilla HTML para enviar nuestro mensaje
                    
                    /*Inicio captura de datos enviados por $_POST para enviar el correo */
                    $mail_setFromEmail=$_POST['customer_email'];
                    $mail_setFromName=$_POST['customer_name'];
                    $txt_message='prueba mensaje';
                    $mail_subject='tu criatura se fugo porque es un mal parido';
                    
                    sendemail($mail_username,$mail_userpassword,$mail_setFromEmail,$mail_setFromName,$mail_addAddress,$txt_message,$mail_subject,$template);//Enviar el mensaje
                
                echo "se ha registrado";
            }else{
                echo $mysql->error;
            }
        }
        
    }
}


