<?php
$mysql = new mysqli("localhost","root","","registroalumnos"); 

if ($mysql->connect_error){
    echo"Error al conectar con la base de datos" . $mysql->connect_error;
}else{
    if(!isset($_POST["siglas"],$_POST["nombre"],$_POST["aula"],$_POST["hora"],$_POST["prof"])){
                
                echo "Error al recibir los datos"; 
            }else{
                $siglas = $_POST["siglas"];
                $nombre = $_POST["nombre"];
                $aula = $_POST["aula"];
                $hora = $_POST["hora"];
                $prof = $_POST["prof"];
                $sql ="insert into asignaturas values (
                   '{$siglas}','{$nombre}',
                   '{$aula}','{$hora}','{$prof}'
                )";

                $res = $mysql->query($sql);

                if(!$res){
                    echo "Error al insertar los datos en la base de datos" . $mysql->error;
                }else{
                    header("Location:../src_html/opciones.php");
                }
            }
}

$mysql->close();
