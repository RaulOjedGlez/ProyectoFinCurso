<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../src_css/registroSalidas.css">

</head>
<body>
    <div id="container1">
        <form method="post">
            <label for="nombreal">Nombre completo del alumno</label>
            <br><br>
            <input type="text" id="nombreal" name="nombreal">
            <br><br>
            <button type="submit" id="buscar"> Buscar </button>
        </form>
    </div>

    <div id='"container2'></div>
</body>
</html>